var translations = new Array();
translations['time_tracking_stopwatch_start'] = 'Розпочати';
translations['time_tracking_stopwatch_stop'] = 'Зупинити';
translations['loading'] = 'Завантаження…';
