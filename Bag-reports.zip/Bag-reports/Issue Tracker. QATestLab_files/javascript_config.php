var config = new Array();
config['datetime_picker_format'] = 'Y-MM-DD HH:mm';
config['short_path'] = '/';
